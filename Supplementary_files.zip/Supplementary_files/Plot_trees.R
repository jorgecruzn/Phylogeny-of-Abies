###Script to plot trees
###By Jorge Cruz-Nicol�s
## Title: Non-adaptive evolutionary processes governed the diversification of a temperate conifer lineage after its migration into the tropics
##Date: February 2021

library("ape")
library("phytools")
library("phangorn")

############################---Figure 2##############################
###--Tree of Maximum Likelihood

ML1 <-read.tree("RAxML_bipartitions.result")
###To root with Abies lasiocarpa
ML1 <- ape::root(ML1, node = 83)
###--Rename tip labels
ML1$tip.label <-c("A.hickelli Ver_01", "A.guatemalensis Chis_03","A.guatemalensis Chis_01",
                  "A.guatemalensis Chis_02","A. guatemalensis GUA_01","A.sp. Gro_01","A.sp. Gro_02",
                  "A.hickelii Oax_06","A.hickelii Oax_07","A.hickelii Oax_05","A.hickelii Oax_04",
                  "A.religiosa Hgo_5316","A.religiosa Col_2112","A.religiosa Mich_1519","A.religiosa Qro_01",
                  "A.religiosa Mich_5502","A.religiosa Ver_4809","A.jaliscana Jal_1807","A.flinckii Mich_1709",
                  "A.jaliscana Jal_1901","A.flinckii Mich_1404","A.flinckii Mich_1606","A.flinckii Col_2004",
                  "A.hidalgensis Hgo_01","A.vejarii NL_03", "A.vejarii NL_02","A.vejarii NL_01",
                  "A.vejarii Coah_01","A.vejarii Coah_05", "A.vejarii Coah_04","A.dur.coahuilensis Coah_03", 
                  "A.dur.coahuilensis Coah_04","A.dur.coahuilensis Coah_02","A.dur.coahuilensis Coah_01",
                  "A.concolor USA_02", "A.lasiocarpa USA","A.concolor Chih_03","A.concolor USA_01",
                  "A.concolor Chih_02","A.sp. Dgo_01","A.sp. Jal_02","A.sp.Dgo_sp001","A.concolor Chih_01",
                  "A.durangensis Dgo_02", "A.durangensis Dgo_01","A.guatemalensis SLP_01")

###-Tree of SVDquartets-########
##--Read tree
linaje_SVD1 <- read.nexus("Abies_SVDquartets.tre")
##--To root with A. lasiocarpa
linaje_SVD1 <- ape::root(linaje_SVD1, node = 54)
###--To rename tip labels
linaje_SVD1$tip.label <- c("A.concolor Chih_01", "A.concolor Chih_02", "A.concolor USA_01", "A.concolor Chih_03", "A.concolor USA_02", "A.lasiocarpa USA",
                           "A.sp. Jal_02", "A.dur.coahuilensis Coah_01", "A.dur.coahuilensis Coah_02", "A.dur.coahuilensis Coah_03", "A.dur.coahuilensis Coah_04",
                           "A.vejarii Coah_01","A.vejarii Coah_04", "A.vejarii Coah_05", "A.vejarii NL_01", "A.vejarii NL_02", "A.vejarii NL_03", 
                           "A.flinckii Col_2004","A.flinckii Mich_1404", "A.flinckii Mich_1606",  "A.flinckii Mich_1709", "A.jaliscana Jal_1807",
                           "A.jaliscana Jal_1901","A.religiosa Col_2112", "A.religiosa Mich_1519", "A.religiosa Mich_5502", "A.religiosa Qro_01",
                           "A.religiosa Hgo_5316","A.religiosa Ver_4809", "A.guatemalensis Chis_01","A.guatemalensis Chis_02","A. guatemalensis GUA_01",
                           "A.guatemalensis Chis_03","A.sp. Gro_01","A.sp. Gro_02","A.hickelii Oax_04","A.hickelii Oax_05",
                           "A.hickelii Oax_07","A.hickelii Oax_06","A.hickelli Ver_01","A.hidalgensis Hgo_01","A.guatemalensis SLP_01",
                           "A.sp. Dgo_01","A.sp.Dgo_sp001","A.durangensis Dgo_01","A.durangensis Dgo_02")

obj <- cophylo(ML1, linaje_SVD1, rotate=TRUE)
plot(obj,link.type="curved",link.lwd=3,link.lty="solid",
     link.col=make.transparent("blue",0.9),fsize=0.6,
     mar=c(.1,.1,1,.1))
title("a) ML                                   b) SVDquartets")

####--Best tree of Maximum likelihood for Figure 3

##---Read tree
MLbest <-read.tree("RAxML_bestTree.result")
####---To root with lasiocarpa
MLbest2 <- ape::root(MLbest, node = 86)
MLbest2$tip.label <- c("A.durangensis Dgo_02", "A.durangensis Dgo_01",
                       "A.guatemalensis SLP_01","A.hickelii Ver_01","A.guatemalensis Chis_03",
                       "A.guatemalensis Chis_01","A.guatemalensis Chis_02","A.guatemalensis GUA_01",
                       "A.sp.Gro_01","A.sp. Gro_02","A.hickelii Oax_06","A.hickelii Oax_07",
                       "A.hickelii Oax_05","A.hickelii Oax_04","A.religiosa Hgo_5316","A.religiosa Col_2112",
                       "A.religiosa Mich_1519","A.religiosa Qro_01","A.religiosa Mich_5502",
                       "A.religiosa Ver_4809","A.jaliscana Jal_1807","A.flinckii Mich_1709", 
                       "A.jaliscana Jal_1901","A.flinckii Mich_1404","A.flinckii Mich_1606",
                       "A.flinckii Col_2004","A.hidalgensis Hgo_01","A.vejarii NL_03", "A.vejarii NL_02","A.vejarii NL_01",  
                       "A.vejarii Coah_01","A.vejarii Coah_05", "A.vejarii Coah_04",
                       "A.dur.coahuilensis Coah_03", "A.dur.coahuilensis Coah_04","A.dur.coahuilensis Coah_02",
                       "A.dur.coahuilensis Coah_01","A.concolor USA_02", "A.lasiocarpa USA",
                       "A.concolor Chih_03","A.concolor USA_01","A.concolor Chih_02","A.sp. Dgo_01",
                       "A.sp. Jal_02","A.sp.Dgo_sp001","A.concolor Chih_01")

####----To rotate

MLbest2rotate <- rotate.multi(MLbest2, node= c (1,6))
plot.phylo(MLbest2rotate,adj=0.05, use.edge.length=FALSE,font=4,cex=0.7,
           main= "", tip.color=c(rep("red",1),rep("darkblue",11), 
                                   rep("green4",13),rep("red",10), rep("gray40",5),
                                   rep("purple",5), rep("black",1), 
                                   label.offset=1, edge.width=3))
